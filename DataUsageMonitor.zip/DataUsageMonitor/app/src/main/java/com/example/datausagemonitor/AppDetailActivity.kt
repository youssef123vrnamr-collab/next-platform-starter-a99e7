package com.example.datausagemonitor

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AppDetailActivity : AppCompatActivity() {

    private lateinit var packageName2: String
    private lateinit var networkUsageHelper: NetworkUsageHelper
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        packageName2 = intent.getStringExtra("package_name") ?: ""
        val appName = intent.getStringExtra("app_name") ?: packageName2

        networkUsageHelper = NetworkUsageHelper(this)
        prefs = getSharedPreferences("usage_limits", Context.MODE_PRIVATE)

        val ivIcon = findViewById<ImageView>(R.id.ivDetailIcon)
        val tvName = findViewById<TextView>(R.id.tvDetailName)
        val tvTotal = findViewById<TextView>(R.id.tvDetailTotal)
        val chart = findViewById<UsageBarChartView>(R.id.barChartView)
        val etLimit = findViewById<EditText>(R.id.etLimitMb)
        val btnSave = findViewById<Button>(R.id.btnSaveLimit)
        val tvLimitStatus = findViewById<TextView>(R.id.tvLimitStatus)

        tvName.text = appName

        try {
            ivIcon.setImageDrawable(packageManager.getApplicationIcon(packageName2))
        } catch (e: Exception) {
            // تجاهل لو مقدرش يجيب الأيقونة
        }

        // آخر 7 أيام للرسم البياني
        val dailyData = networkUsageHelper.getDailyUsageForApp(packageName2, 7)
        chart.setData(dailyData)

        val totalBytes = dailyData.values.sum()
        tvTotal.text = "إجمالي آخر 7 أيام: ${DataFormatter.formatBytes(totalBytes)}"

        // تحميل الحد المحفوظ سابقًا لو موجود
        val savedLimitMb = prefs.getInt(packageName2, -1)
        if (savedLimitMb > 0) {
            etLimit.setText(savedLimitMb.toString())
            checkLimitStatus(savedLimitMb, totalBytes, tvLimitStatus)
        }

        btnSave.setOnClickListener {
            val value = etLimit.text.toString().toIntOrNull()
            if (value == null || value <= 0) {
                Toast.makeText(this, "من فضلك أدخل رقم صحيح بالميجابايت", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putInt(packageName2, value).apply()
            Toast.makeText(this, "تم حفظ الحد الأقصى", Toast.LENGTH_SHORT).show()
            checkLimitStatus(value, totalBytes, tvLimitStatus)
        }
    }

    private fun checkLimitStatus(limitMb: Int, usedBytes: Long, tvLimitStatus: TextView) {
        val limitBytes = limitMb.toLong() * 1024 * 1024
        if (usedBytes >= limitBytes) {
            tvLimitStatus.text = "⚠️ تم تجاوز الحد الأقصى المحدد!"
            tvLimitStatus.setTextColor(android.graphics.Color.RED)
        } else {
            val remaining = limitBytes - usedBytes
            tvLimitStatus.text = "متبقي قبل الوصول للحد: ${DataFormatter.formatBytes(remaining)}"
            tvLimitStatus.setTextColor(android.graphics.Color.GRAY)
        }
    }
}
