package com.example.datausagemonitor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppUsageAdapter(
    private var items: List<AppUsageInfo>,
    private val onClick: (AppUsageInfo) -> Unit
) : RecyclerView.Adapter<AppUsageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.ivAppIcon)
        val name: TextView = view.findViewById(R.id.tvAppName)
        val total: TextView = view.findViewById(R.id.tvTotalUsage)
        val breakdown: TextView = view.findViewById(R.id.tvBreakdown)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_usage, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.icon.setImageDrawable(item.icon)
        holder.name.text = item.appName
        holder.total.text = DataFormatter.formatBytes(item.totalBytes)
        holder.breakdown.text =
            "واي فاي: ${DataFormatter.formatBytes(item.wifiBytes)}  •  بيانات: ${DataFormatter.formatBytes(item.mobileBytes)}"

        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<AppUsageInfo>) {
        items = newItems
        notifyDataSetChanged()
    }
}
