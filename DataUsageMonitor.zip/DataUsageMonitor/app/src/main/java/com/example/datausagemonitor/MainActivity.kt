package com.example.datausagemonitor

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var networkUsageHelper: NetworkUsageHelper
    private lateinit var adapter: AppUsageAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var tvPermissionWarning: TextView
    private lateinit var tvTotalSummary: TextView

    // 0 = اليوم, 1 = آخر 7 أيام, 2 = آخر 30 يوم
    private var selectedPeriod = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        networkUsageHelper = NetworkUsageHelper(this)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        tvPermissionWarning = findViewById(R.id.tvPermissionWarning)
        tvTotalSummary = findViewById(R.id.tvTotalSummary)

        adapter = AppUsageAdapter(emptyList()) { app ->
            val intent = Intent(this, AppDetailActivity::class.java)
            intent.putExtra("package_name", app.packageName)
            intent.putExtra("app_name", app.appName)
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        tvPermissionWarning.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        findViewById<Button>(R.id.btnToday).setOnClickListener {
            selectedPeriod = 0
            loadData()
        }
        findViewById<Button>(R.id.btnWeek).setOnClickListener {
            selectedPeriod = 1
            loadData()
        }
        findViewById<Button>(R.id.btnMonth).setOnClickListener {
            selectedPeriod = 2
            loadData()
        }
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }

    private fun loadData() {
        if (!networkUsageHelper.hasUsageAccessPermission()) {
            tvPermissionWarning.visibility = android.view.View.VISIBLE
            recyclerView.visibility = android.view.View.GONE
            tvTotalSummary.text = ""
            return
        }

        tvPermissionWarning.visibility = android.view.View.GONE
        recyclerView.visibility = android.view.View.VISIBLE

        val (start, end) = getRangeForPeriod(selectedPeriod)

        // بما إن queryDetailsForUid ممكن تاخد وقت مع عدد كبير من التطبيقات
        // في تطبيق حقيقي يفضل نعملها في خيط تاني (Thread/Coroutine)، هنا مبسطة للتوضيح
        val list = networkUsageHelper.getUsageForAllApps(start, end)
        adapter.updateData(list)

        val totalBytes = list.sumOf { it.totalBytes }
        tvTotalSummary.text = "إجمالي الاستهلاك: ${DataFormatter.formatBytes(totalBytes)}"
    }

    private fun getRangeForPeriod(period: Int): Pair<Long, Long> {
        val end = System.currentTimeMillis()
        val cal = Calendar.getInstance()

        when (period) {
            0 -> {
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
            }
            1 -> cal.add(Calendar.DAY_OF_YEAR, -7)
            2 -> cal.add(Calendar.DAY_OF_YEAR, -30)
        }

        return Pair(cal.timeInMillis, end)
    }
}
