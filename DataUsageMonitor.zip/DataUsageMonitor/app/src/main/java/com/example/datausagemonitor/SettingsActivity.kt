package com.example.datausagemonitor

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * شاشة إعدادات مبسطة - مكانها جاهز عشان تضيف عليها مميزات جديدة بسهولة
 * زي: تفعيل/تعطيل التنبيهات، اختيار الوحدة الافتراضية، تصدير التقرير، إلخ
 */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "شاشة الإعدادات - جاهزة للتوسعة بمميزات إضافية"
        tv.setPadding(32, 32, 32, 32)
        tv.textSize = 16f
        setContentView(tv)
    }
}
