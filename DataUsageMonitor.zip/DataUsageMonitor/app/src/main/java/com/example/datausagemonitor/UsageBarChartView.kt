package com.example.datausagemonitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * رسم بياني بسيط (أعمدة) لعرض الاستهلاك اليومي بدون أي مكتبة خارجية
 * بيرسم مباشرة على Canvas عشان يفضل التطبيق شغال أوفلاين ١٠٠٪
 */
class UsageBarChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var data: LinkedHashMap<Long, Long> = LinkedHashMap()

    private val barPaint = Paint().apply {
        color = Color.parseColor("#1976D2")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.parseColor("#616161")
        textSize = 26f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val dateFormat = SimpleDateFormat("EEE", Locale("ar"))

    fun setData(newData: LinkedHashMap<Long, Long>) {
        data = newData
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) return

        val maxValue = data.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
        val entries = data.entries.toList()
        val barCount = entries.size
        val paddingBottom = 60f
        val paddingTop = 20f
        val availableHeight = height - paddingBottom - paddingTop
        val slotWidth = width.toFloat() / barCount
        val barWidth = slotWidth * 0.5f

        for (i in entries.indices) {
            val (timestamp, bytes) = entries[i]
            val ratio = bytes.toFloat() / maxValue.toFloat()
            val barHeight = availableHeight * ratio
            val left = i * slotWidth + (slotWidth - barWidth) / 2f
            val top = paddingTop + (availableHeight - barHeight)
            val right = left + barWidth
            val bottom = paddingTop + availableHeight

            canvas.drawRect(left, top, right, bottom, barPaint)

            // تسمية اليوم تحت العمود
            val label = dateFormat.format(Date(timestamp))
            canvas.drawText(label, left + barWidth / 2f, height - 15f, textPaint)
        }
    }
}
