package com.example.datausagemonitor

import android.graphics.drawable.Drawable

/**
 * يمثل بيانات استهلاك تطبيق واحد
 */
data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val wifiBytes: Long,
    val mobileBytes: Long
) {
    val totalBytes: Long
        get() = wifiBytes + mobileBytes
}

/**
 * دوال مساعدة لتحويل البايت إلى صيغة مقروءة (كيلوبايت / ميجابايت / جيجابايت)
 */
object DataFormatter {

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 KB"

        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.2f MB", mb)
            else -> String.format("%.0f KB", kb)
        }
    }

    // يرجع القيمة بالتفصيل: جيجا + ميجا + كيلو منفصلين، لو المستخدم عايز التفصيل الكامل
    fun formatDetailed(bytes: Long): String {
        var remaining = bytes
        val gb = remaining / (1024 * 1024 * 1024)
        remaining -= gb * 1024 * 1024 * 1024
        val mb = remaining / (1024 * 1024)
        remaining -= mb * 1024 * 1024
        val kb = remaining / 1024

        val parts = mutableListOf<String>()
        if (gb > 0) parts.add("$gb GB")
        if (mb > 0) parts.add("$mb MB")
        if (kb > 0 || parts.isEmpty()) parts.add("$kb KB")
        return parts.joinToString(" ")
    }
}
