package com.example.datausagemonitor

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.os.Process
import android.telephony.TelephonyManager

/**
 * المسؤول عن قراءة بيانات استهلاك الشبكة لكل تطبيق مثبت
 * باستخدام NetworkStatsManager الرسمي من أندرويد
 */
class NetworkUsageHelper(private val context: Context) {

    private val networkStatsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager

    /**
     * تتأكد إن المستخدم فعّل صلاحية "الوصول لبيانات الاستخدام" يدويًا
     */
    fun hasUsageAccessPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * يجيب استهلاك كل التطبيقات المثبتة خلال فترة زمنية معينة (بالميلي ثانية)
     * ويرجع قايمة مرتبة تنازليًا حسب إجمالي الاستهلاك
     */
    fun getUsageForAllApps(startTime: Long, endTime: Long): List<AppUsageInfo> {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        val subscriberId = getSubscriberIdSafe()
        val result = mutableListOf<AppUsageInfo>()

        for (app in installedApps) {
            // تجاهل تطبيقات النظام اللي مالهاش واجهة (اختياري، ممكن تشيل الشرط لو عايز كل حاجة)
            val uid = app.uid

            val mobileBytes = try {
                queryBytesForUid(
                    ConnectivityManager.TYPE_MOBILE,
                    subscriberId,
                    startTime,
                    endTime,
                    uid
                )
            } catch (e: Exception) {
                0L
            }

            val wifiBytes = try {
                queryBytesForUid(
                    ConnectivityManager.TYPE_WIFI,
                    "",
                    startTime,
                    endTime,
                    uid
                )
            } catch (e: Exception) {
                0L
            }

            if (mobileBytes > 0 || wifiBytes > 0) {
                val appName = try {
                    pm.getApplicationLabel(app).toString()
                } catch (e: Exception) {
                    app.packageName
                }
                val icon = try {
                    pm.getApplicationIcon(app.packageName)
                } catch (e: Exception) {
                    null
                }

                result.add(
                    AppUsageInfo(
                        packageName = app.packageName,
                        appName = appName,
                        icon = icon,
                        wifiBytes = wifiBytes,
                        mobileBytes = mobileBytes
                    )
                )
            }
        }

        return result.sortedByDescending { it.totalBytes }
    }

    /**
     * يجيب الاستهلاك اليومي لتطبيق واحد على مدار عدد أيام معين (لعمل الرسم البياني)
     * يرجع Map من (بداية اليوم بالميلي ثانية) إلى (إجمالي البايتات في هذا اليوم)
     */
    fun getDailyUsageForApp(
        packageName: String,
        days: Int,
        endTime: Long = System.currentTimeMillis()
    ): LinkedHashMap<Long, Long> {
        val pm = context.packageManager
        val uid = try {
            pm.getApplicationInfo(packageName, 0).uid
        } catch (e: Exception) {
            return LinkedHashMap()
        }

        val subscriberId = getSubscriberIdSafe()
        val dayMillis = 24L * 60 * 60 * 1000
        val result = LinkedHashMap<Long, Long>()

        for (i in (days - 1) downTo 0) {
            val dayStart = endTime - (i + 1) * dayMillis
            val dayEnd = endTime - i * dayMillis

            val mobile = try {
                queryBytesForUid(ConnectivityManager.TYPE_MOBILE, subscriberId, dayStart, dayEnd, uid)
            } catch (e: Exception) { 0L }

            val wifi = try {
                queryBytesForUid(ConnectivityManager.TYPE_WIFI, "", dayStart, dayEnd, uid)
            } catch (e: Exception) { 0L }

            result[dayStart] = mobile + wifi
        }

        return result
    }

    private fun queryBytesForUid(
        networkType: Int,
        subscriberId: String,
        start: Long,
        end: Long,
        uid: Int
    ): Long {
        var total = 0L
        val bucket = NetworkStats.Bucket()

        val stats: NetworkStats = networkStatsManager.queryDetailsForUid(
            networkType,
            subscriberId,
            start,
            end,
            uid
        )

        while (stats.hasNextBucket()) {
            stats.getNextBucket(bucket)
            total += bucket.rxBytes + bucket.txBytes
        }
        stats.close()
        return total
    }

    private fun getSubscriberIdSafe(): String {
        // مش لازم دايمًا؛ لو مفيش صلاحية READ_PHONE_STATE هنرجع فاضي وده بيشتغل تمام مع queryDetailsForUid
        return ""
    }
}
